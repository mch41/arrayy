#include "MyForm.h"
#include <Windows.h>
//#include "c.time"

using namespace Project7;

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int){



	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Application::Run(gcnew MyForm);
	return 0;
}

